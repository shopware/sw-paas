# Changelog

## [0.0.47](https://github.com/shopware/paas-cli/compare/v0.0.46...0.0.47) (2026-04-27)


### Bug Fixes

* do not include v in tag ([e0a0605](https://github.com/shopware/paas-cli/commit/e0a0605f0e32b6430490d7461fdc933c9b374c4d))

## [0.0.46](https://github.com/shopware/paas-cli/compare/0.0.45...v0.0.46) (2026-04-27)


### Features

* add bundle support for TUI ([b410d74](https://github.com/shopware/paas-cli/commit/b410d74c2412fde88896b4302d82341208313f3d))
* add multiselect ([c7e1c2d](https://github.com/shopware/paas-cli/commit/c7e1c2d6e084713722423eff2ae324fbf3b53808))
* add release-please ([e487da0](https://github.com/shopware/paas-cli/commit/e487da05009afd55da81ab5e99a0b464e3e0ae46))
* policy management, service accounts, and user role self service ([#326](https://github.com/shopware/paas-cli/issues/326)) ([489680b](https://github.com/shopware/paas-cli/commit/489680bf3a694a7b95be5f9de6dbad337348c484))
* show deployed bundle as name@version in admin deployment get command ([5692804](https://github.com/shopware/paas-cli/commit/5692804372fb045a2b75b0482b9dc0e28318dde2))


### Bug Fixes

* vault selection ([#360](https://github.com/shopware/paas-cli/issues/360)) ([3105fe2](https://github.com/shopware/paas-cli/commit/3105fe2c5e97dc39a4c0b04319bcaa9c8f6de06d))
