## sw-paas

### Synopsis

Shopware PaaS CLI is a command line interface for the Shopware PaaS API.

Code: <https://github.com/shopware/paas-cli>

Docs: <https://github.com/shopware/paas-cli/blob/main/README.md>

### Options

```
      --base-url string   specify the base URL of the API server
      --chdir string      change working directory
      --config string     config file (default is $XDG_CONFIG_HOME/sw-paas/config.yaml)
      --debug             enable debug output
  -h, --help              help for sw-paas
```

### SEE ALSO

- [sw-paas application](docs/generated/sw-paas_application.md) - Commands regarding applications
- [sw-paas auth](docs/generated/sw-paas_auth.md) - Authenticate with Shopware PaaS
- [sw-paas completion](docs/generated/sw-paas_completion.md) - Generate the autocompletion script for the specified shell
- [sw-paas deploy](docs/generated/sw-paas_deploy.md) - Deploy the current project
- [sw-paas docs](docs/generated/sw-paas_docs.md) - Generates documentation
- [sw-paas local](docs/generated/sw-paas_local.md) - Local commands
- [sw-paas project](docs/generated/sw-paas_project.md) - Commands for managing projects
- [sw-paas watch](docs/generated/sw-paas_watch.md) - Watch for events

### Development

#### Prerequisites

- [Docker](https://docs.docker.com/get-docker/)
- [Docker Compose](https://docs.docker.com/compose/install/)

#### Git Hooks

Please install the git hooks by running the following command:

```bash
make install-hooks
```

#### Releasing a new version

To release a new version, all that's needed is to create a new tag and pushing it to the repository:

```bash
git tag -s vX.Y.Z -m "Release vX.Y.Z"

# Afterwards:
# git push origin refs/tags/vX.Y.Z
```

This will trigger a GitHub Action that will build the binary, container image and create a new release.

#### Makefile targets

##### tidy

Executes go mod tidy

```bash
make tidy
```

##### lint

Lints all project files

```bash
make lint
```

##### test

Runs all tests

```bash
make test
```

##### generate_docs

Generates documentation and README.md

```bash
make generate_docs
```

##### generate_mocks

Generates mock classes for all interfaces configured in .mockery.yaml

```bash
make generate_mocks
```

##### build

Builds the application. The binary will be placed in the source directory as "sw-paas".

```bash
make build
```

##### run

Runs the application without outputting a binary

```bash
make run
```

##### install-hooks

Installs git hooks

```bash
make install-hooks
```
